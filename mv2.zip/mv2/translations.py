TRANSLATIONS = {
    "uz": {
        "welcome": "Assalomu alaykum, {}! 😊 Maqsadlaringizga bir qadam yaqinlashishga tayyormisiz?",
        "enter_name": "Ismingizni kiriting:",
        "choose_motivation": "Qaysi turdagi motivatsiya sizga mos?",
        "motivation_selected": "🎉 {} motivatsiya tanlandi!\n\n{}",
        "challenge_started": "Siz {} kunlik {} challenge’ini boshladingiz! 📚 Birinchi kun topshirig‘i: {}",
        "profile": "👤 Profil\nIsm: {}\nMotivatsiya turi: {}\nMaqsad: {}\nYutuqlar: {}",
        "invalid_name": "Iltimos, ismingizni to‘g‘ri kiriting:",
        "admin_welcome": "Admin paneliga xush kelibsiz! Nima qilamiz?",
        "admin_no_access": "Sizda admin huquqlari yo‘q.",
        "daily_quote": "📜 Bugungi motivatsiya:\n\n{}"
    },
    "en": {
        "welcome": "Hello, {}! 😊 Ready to take a step toward your goals?",
        "enter_name": "Please enter your name:",
        "choose_motivation": "Which type of motivation suits you?",
        "motivation_selected": "🎉 {} motivation selected!\n\n{}",
        "challenge_started": "You’ve started a {} day {} challenge! 📚 First day task: {}",
        "profile": "👤 Profile\nName: {}\nMotivation type: {}\nGoal: {}\nAchievements: {}",
        "invalid_name": "Please enter a valid name:",
        "admin_welcome": "Welcome to the admin panel! What do we do?",
        "admin_no_access": "You don’t have admin permissions.",
        "daily_quote": "📜 Today’s motivation:\n\n{}"
    }
}

def get_text(key, language="uz", *args):
    """Tarjima matnini olish."""
    return TRANSLATIONS.get(language, TRANSLATIONS["uz"]).get(key, key).format(*args)