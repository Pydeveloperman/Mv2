from apscheduler.schedulers.asyncio import AsyncIOScheduler
from aiogram import Bot
import sqlite3
from datetime import datetime
from database import get_random_quote, get_user
from translations import get_text
import os

# DB yo‘li to‘g‘ridan-to‘g‘ri kiritilgan
DB_PATH = "database/bot.db"

async def send_daily_quote(bot: Bot):
    """Foydalanuvchilarga kundalik iqtibos yuborish."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT user_id, motivation_type, language FROM users")
    users = cursor.fetchall()
    conn.close()

    for user_id, motivation_type, language in users:
        quote = get_random_quote(motivation_type)
        try:
            await bot.send_message(
                user_id,
                get_text("daily_quote", language, quote)
            )
        except Exception as e:
            print(f"Xabar yuborishda xato (user_id: {user_id}): {e}")

def setup_scheduler(bot: Bot):
    """Scheduler sozlash."""
    scheduler = AsyncIOScheduler()
    # Har kuni soat 8:00 da xabar yuborish
    scheduler.add_job(send_daily_quote, "cron", hour=8, minute=0, args=[bot])
    scheduler.start()