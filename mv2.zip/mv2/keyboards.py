from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
import emoji

def get_main_menu(language="uz"):
    """Asosiy menyu (Reply Keyboard)."""
    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    buttons = [
        KeyboardButton(f"{emoji.emojize(':dart:')} Motivatsiya" if language == "uz" else "Motivation"),
        KeyboardButton(f"{emoji.emojize(':white_check_mark:')} Challenge" if language == "uz" else "Challenge"),
        KeyboardButton(f"{emoji.emojize(':light_bulb:')} G‘oya" if language == "uz" else "Idea"),
        KeyboardButton(f"{emoji.emojize(':timer_clock:')} Pomodoro" if language == "uz" else "Pomodoro"),
        KeyboardButton(f"{emoji.emojize(':memo:')} Rejalar" if language == "uz" else "Plans"),
        KeyboardButton(f"{emoji.emojize(':bust_in_silhouette:')} Profil" if language == "uz" else "Profile")
    ]
    markup.add(*buttons)
    return markup

def get_motivation_types(language="uz"):
    """Motivatsiya turlari (Inline Keyboard)."""
    markup = InlineKeyboardMarkup(row_width=2)
    buttons = [
        InlineKeyboardButton("Psixologik" if language == "uz" else "Psychological", callback_data="motivation_psixologik"),
        InlineKeyboardButton("Diniy" if language == "uz" else "Religious", callback_data="motivation_diniy"),
        InlineKeyboardButton("Biznes" if language == "uz" else "Business", callback_data="motivation_biznes"),
        InlineKeyboardButton("Ilmiy" if language == "uz" else "Scientific", callback_data="motivation_ilmiy")
    ]
    markup.add(*buttons)
    markup.add(InlineKeyboardButton("⬅️ Orqaga" if language == "uz" else "Back", callback_data="back_to_main"))
    return markup

def get_challenge_types(language="uz"):
    """Challenge turlari (Inline Keyboard)."""
    markup = InlineKeyboardMarkup(row_width=2)
    buttons = [
        InlineKeyboardButton("Fitness" if language == "uz" else "Fitness", callback_data="challenge_fitness_7"),
        InlineKeyboardButton("Kitobxonlik" if language == "uz" else "Reading", callback_data="challenge_reading_30"),
        InlineKeyboardButton("Til o‘rganish" if language == "uz" else "Language Learning", callback_data="challenge_language_30")
    ]
    markup.add(*buttons)
    markup.add(InlineKeyboardButton("⬅️ Orqaga" if language == "uz" else "Back", callback_data="back_to_main"))
    return markup

def get_admin_menu():
    """Admin menyusi (Inline Keyboard)."""
    markup = InlineKeyboardMarkup(row_width=2)
    buttons = [
        InlineKeyboardButton("Iqtibos qo‘shish", callback_data="admin_add_quote"),
        InlineKeyboardButton("Statistika", callback_data="admin_stats"),
        InlineKeyboardButton("Xabar yuborish", callback_data="admin_broadcast"),
        InlineKeyboardButton("⬅️ Chiqish", callback_data="admin_exit")
    ]
    markup.add(*buttons)
    return markup