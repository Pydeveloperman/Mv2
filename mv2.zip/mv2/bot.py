import asyncio
import os
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from dotenv import load_dotenv
from database import init_db, add_user, get_user, update_user, add_quote, get_random_quote, add_challenge, get_user_challenges, update_challenge_progress, add_badge, get_user_badges
from keyboards import get_main_menu, get_motivation_types, get_challenge_types, get_admin_menu
from translations import get_text
from scheduler import setup_scheduler
import emoji
from datetime import datetime

# .env faylidan ma'lumotlarni o'qish
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

# Bot va Dispatcher
bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot=bot, storage=storage)

# FSM holatlari
class UserFlow(StatesGroup):
    waiting_for_name = State()
    waiting_for_motivation = State()
    waiting_for_admin_quote = State()
    waiting_for_broadcast = State()

# Ma'lumotlar bazasini ishga tushirish
init_db()

@dp.message(CommandStart())
async def start_command(message: types.Message, state: FSMContext):
    user = get_user(message.from_user.id)
    if not user:
        await message.answer(
            get_text("enter_name", "uz"),
            reply_markup=types.ReplyKeyboardRemove()
        )
        await state.set_state(UserFlow.waiting_for_name)
    else:
        await message.answer(
            get_text("welcome", user[5], user[1]),
            reply_markup=get_main_menu(user[5])
        )

@dp.message(UserFlow.waiting_for_name)
async def process_name(message: types.Message, state: FSMContext):
    name = message.text.strip()
    if len(name) < 2:
        await message.answer(get_text("invalid_name", "uz"))
        return
    add_user(message.from_user.id, name)
    await message.answer(
        get_text("choose_motivation", "uz"),
        reply_markup=get_motivation_types()
    )
    await state.set_state(UserFlow.waiting_for_motivation)

@dp.callback_query(lambda c: c.data.startswith("motivation_"))
async def process_motivation(callback: types.CallbackQuery, state: FSMContext):
    motivation_type = callback.data.split("_")[1].capitalize()
    user_id = callback.from_user.id
    user = get_user(user_id)
    update_user(user_id, motivation_type=motivation_type)
    quote = get_random_quote(motivation_type)
    await callback.message.answer(
        get_text("motivation_selected", user[5], motivation_type, quote),
        reply_markup=get_main_menu(user[5])
    )
    await callback.message.delete()
    await state.clear()

@dp.callback_query(lambda c: c.data.startswith("challenge_"))
async def process_challenge(callback: types.CallbackQuery, state: FSMContext):
    user = get_user(callback.from_user.id)
    data = callback.data.split("_")
    challenge_type = data[1].capitalize()
    total_days = int(data[2])
    add_challenge(callback.from_user.id, challenge_type, total_days)
    task = "10 sahifa o‘qing" if challenge_type == "Reading" else "30 daqiqa mashq qiling"
    await callback.message.answer(
        get_text("challenge_started", user[5], total_days, challenge_type, task),
        reply_markup=get_main_menu(user[5])
    )
    await callback.message.delete()
    await state.clear()

@dp.message(lambda message: message.text in [f"{emoji.emojize(':dart:')} Motivatsiya", "Motivation"])
async def show_motivation(message: types.Message):
    user = get_user(message.from_user.id)
    if user:
        quote = get_random_quote(user[2])
        await message.answer(get_text("daily_quote", user[5], quote))
    else:
        await message.answer(get_text("invalid_name", "uz"))

@dp.message(lambda message: message.text in [f"{emoji.emojize(':white_check_mark:')} Challenge", "Challenge"])
async def show_challenges(message: types.Message):
    user = get_user(message.from_user.id)
    if user:
        await message.answer(
            get_text("choose_motivation", user[5]),
            reply_markup=get_challenge_types(user[5])
        )
    else:
        await message.answer(get_text("invalid_name", user[5]))

@dp.message(lambda message: message.text in [f"{emoji.emojize(':bust_in_silhouette:')} Profil", "Profile"])
async def show_profile(message: types.Message):
    user = get_user(message.from_user.id)
    if user:
        badges = get_user_badges(message.from_user.id)
        badges_text = "\n".join([f"🏅 {b[0]} ({b[1]})" for b in badges]) or "Hozircha yutuqlar yo‘q."
        await message.answer(
            get_text("profile", user[5], user[1], user[2], user[3], badges_text),
            reply_markup=get_main_menu(user[5])
        )
    else:
        await message.answer(get_text("invalid_name", user[5]))

@dp.message(Command("admin"))
async def admin_panel(message: types.Message, state: FSMContext):
    if message.from_user.id == ADMIN_ID:
        await message.answer(
            get_text("admin_welcome", "uz"),
            reply_markup=get_admin_menu()
        )
    else:
        await message.answer(get_text("admin_no_access", "uz"))

@dp.callback_query(lambda c: c.data == "admin_add_quote")
async def admin_add_quote(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id == ADMIN_ID:
        await callback.message.answer("Iqtibos matnini kiriting:")
        await state.set_state(UserFlow.waiting_for_admin_quote)
    else:
        await callback.message.answer(get_text("admin_no_access", "uz"))

@dp.message(UserFlow.waiting_for_admin_quote)
async def process_admin_quote(message: types.Message, state: FSMContext):
    add_quote(message.text, "Psixologik", "Fokus")
    await message.answer("Iqtibos qo‘shildi!", reply_markup=get_admin_menu())
    await state.clear()

@dp.callback_query(lambda c: c.data == "admin_broadcast")
async def admin_broadcast(callback: types.CallbackQuery, state: FSMContext):
    if callback.from_user.id == ADMIN_ID:
        await callback.message.answer("Barcha foydalanuvchilarga yuboriladigan xabarni kiriting:")
        await state.set_state(UserFlow.waiting_for_broadcast)
    else:
        await callback.message.answer(get_text("admin_no_access", "uz"))

@dp.message(UserFlow.waiting_for_broadcast)
async def process_broadcast(message: types.Message, state: FSMContext):
    if message.from_user.id == ADMIN_ID:
        conn = sqlite3.connect(os.getenv("DB_PATH"))
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM users")
        users = cursor.fetchall()
        conn.close()
        for user_id in users:
            try:
                await bot.send_message(user_id[0], message.text)
            except Exception as e:
                print(f"Xabar yuborishda xato (user_id: {user_id[0]}): {e}")
        await message.answer("Xabar yuborildi!", reply_markup=get_admin_menu())
        await state.clear()

@dp.callback_query(lambda c: c.data == "admin_exit")
async def admin_exit(callback: types.CallbackQuery, state: FSMContext):
    user = get_user(callback.from_user.id)
    await callback.message.answer(
        get_text("welcome", user[5], user[1]),
        reply_markup=get_main_menu(user[5])
    )
    await callback.message.delete()
    await state.clear()

@dp.callback_query(lambda c: c.data == "back_to_main")
async def back_to_main(callback: types.CallbackQuery, state: FSMContext):
    user = get_user(callback.from_user.id)
    await callback.message.answer(
        get_text("welcome", user[5], user[1]),
        reply_markup=get_main_menu(user[5])
    )
    await callback.message.delete()
    await state.clear()

async def main():
    setup_scheduler(bot)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())