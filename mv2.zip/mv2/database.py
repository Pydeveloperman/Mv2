import sqlite3
import os

DB_PATH = "/database/bot.db"

def init_db():
    """Ma'lumotlar bazasini yaratish va jadvallarni sozlash."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Users jadvali
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            name TEXT,
            motivation_type TEXT,
            goal TEXT,
            notification_time TEXT,
            language TEXT DEFAULT 'uz',
            progress INTEGER DEFAULT 0
        )
    """)

    # Quotes jadvali
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS quotes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT,
            category TEXT,
            goal_type TEXT
        )
    """)

    # Challenges jadvali
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS challenges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            type TEXT,
            total_days INTEGER,
            progress INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    # Badges jadvali
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS badges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            badge_name TEXT,
            awarded_at TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    conn.commit()
    conn.close()

def add_user(user_id, name, motivation_type="Psixologik", goal="Fokus", notification_time="08:00", language="uz"):
    """Foydalanuvchini qo'shish."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR REPLACE INTO users (user_id, name, motivation_type, goal, notification_time, language) VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, name, motivation_type, goal, notification_time, language)
    )
    conn.commit()
    conn.close()

def get_user(user_id):
    """Foydalanuvchi ma'lumotlarini olish."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    return user

def update_user(user_id, **kwargs):
    """Foydalanuvchi ma'lumotlarini yangilash."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    query = "UPDATE users SET " + ", ".join(f"{k} = ?" for k in kwargs) + " WHERE user_id = ?"
    cursor.execute(query, list(kwargs.values()) + [user_id])
    conn.commit()
    conn.close()

def add_quote(text, category, goal_type):
    """Iqtibos qo'shish."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO quotes (text, category, goal_type) VALUES (?, ?, ?)",
        (text, category, goal_type)
    )
    conn.commit()
    conn.close()

def get_random_quote(category="Psixologik"):
    """Tasodifiy iqtibos olish."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT text FROM quotes WHERE category = ? ORDER BY RANDOM() LIMIT 1", (category,))
    quote = cursor.fetchone()
    conn.close()
    return quote[0] if quote else "Iqtibos topilmadi."

def add_challenge(user_id, challenge_type, total_days):
    """Challenge qo'shish."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO challenges (user_id, type, total_days) VALUES (?, ?, ?)",
        (user_id, challenge_type, total_days)
    )
    conn.commit()
    conn.close()

def update_challenge_progress(challenge_id, progress):
    """Challenge progressini yangilash."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE challenges SET progress = ? WHERE id = ?",
        (progress, challenge_id)
    )
    conn.commit()
    conn.close()

def get_user_challenges(user_id):
    """Foydalanuvchi challengelarni olish."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM challenges WHERE user_id = ?", (user_id,))
    challenges = cursor.fetchall()
    conn.close()
    return challenges

def add_badge(user_id, badge_name, awarded_at):
    """Badge qo'shish."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO badges (user_id, badge_name, awarded_at) VALUES (?, ?, ?)",
        (user_id, badge_name, awarded_at)
    )
    conn.commit()
    conn.close()

def get_user_badges(user_id):
    """Foydalanuvchi badgelarini olish."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT badge_name, awarded_at FROM badges WHERE user_id = ?", (user_id,))
    badges = cursor.fetchall()
    conn.close()
    return badges